import java.io.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;

public class Users {
    private Set<String> blockedUsers = new HashSet<>();
    private Map<String, Integer> failedAttempts = new HashMap<>();

    public boolean Login(String username, String password, HashMap<String, String> info) {
        if (blockedUsers.contains(username)) {
            System.out.println("This account has been blocked! ❌");
            return false;
        }

        if (info.containsKey(username) && info.get(username).equals(password)) {
            failedAttempts.put(username, 0);
            logUser(username);
            return true;
        } else {
            int attempts = failedAttempts.getOrDefault(username, 0) + 1;
            failedAttempts.put(username, attempts);

            if (attempts >= 3) {
                blockedUsers.add(username);
                System.out.println("This account has been blocked due to 3 unsuccessful login attempts! ❌");
            }
            return false;
        }
    }

    private void logUser(String username) {
        try (FileWriter fw = new FileWriter("Users.log", true)) {
            LocalDateTime now = LocalDateTime.now();
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
            fw.write(username + " - " + now.format(formatter) + "\n");
        } catch (IOException e) {
            System.out.println("Error saving username: " + e.getMessage());
        }
    }

    public void Register(String username, String password, String confirmPassword, HashMap<String, String> info) {
        boolean result = validate(username, password, confirmPassword, info);
        if (!result) {
            System.out.println("Invalid username or password!");
        } else {
            info.put(username, password);
            System.out.println("Register successful!");
        }
    }

    public boolean validate(String username, String password, String confirmPassword, HashMap<String, String> info) {
        if (info.containsKey(username)) {
            return false;
        } else if (!password.equals(confirmPassword)) {
            return false;
        } else if (password.length() < 8) {
            return false;
        } else {
            return true;
        }
    }

    public void userMenu(String username, String password, HashMap<String, String> info) {
        Scanner input = new Scanner(System.in);
        while (true) {
            if (!username.equals("admin")) {
                System.out.println("1.Delete Account");
            }
            System.out.println("2.Change Password 3.Logout");

            if (username.equals("admin")) {
                System.out.println("4.View All Accounts 5.View Login Log 6.View Blocked Users 7.Unblock User");
            }

            System.out.print("Enter your choice: ");
            String choice = input.nextLine();

            if (choice.equals("1") && !username.equals("admin")) {
                System.out.print("Are you sure you want to delete this account? (yes/no): ");
                if (input.nextLine().equalsIgnoreCase("yes")) {
                    info.remove(username);
                    System.out.println("Delete successful!");
                    break;
                } else {
                    System.out.println("Delete failed!");
                }

            } else if (choice.equals("2")) {
                System.out.println("Are you sure you want to change your password? (yes/no): ");
                if (input.nextLine().equalsIgnoreCase("yes")) {
                    System.out.println("Please enter your old password: ");
                    if (input.nextLine().equals(password)) {
                        System.out.println("Please enter your new password: ");
                        String newPassword = input.nextLine();
                        if (newPassword.length() < 8) {
                            System.out.println("New password must be at least 8 characters long!");
                        } else if (newPassword.equals(password)) {
                            System.out.println("New password cannot be the same as the old password!");
                        } else {
                            System.out.println("Please confirm your new password: ");
                            String confirmNewPassword = input.nextLine();
                            if (confirmNewPassword.equals(newPassword)) {
                                password = newPassword;
                                info.put(username, password);
                                System.out.println("Your new password has been changed!");
                            } else {
                                System.out.println("Your new password does not match!");
                            }
                        }
                    } else {
                        System.out.println("Your old password does not match!");
                    }
                } else {
                    System.out.println("Password change canceled!");
                }
            } else if (choice.equals("3")) {
                break;
            } else if (choice.equals("4") && username.equals("admin")) {
                System.out.println("=== All Accounts ===");
                for (String user : info.keySet()) {
                    System.out.println("Username: " + user + "\nPassword: " + info.get(user));
                }
            } else if (choice.equals("5") && username.equals("admin")) {
                System.out.println("=== Login Log ===");
                try (BufferedReader br = new BufferedReader(new FileReader("Users.log"))) {
                    String line;
                    while ((line = br.readLine()) != null) {
                        System.out.println(line);
                    }
                } catch (IOException e) {
                    System.out.println("Error reading file: " + e.getMessage());
                }
            } else if (choice.equals("6") && username.equals("admin")) {
                System.out.println("=== Blocked Users ===");
                if (blockedUsers.isEmpty()) {
                    System.out.println("No blocked users.");
                } else {
                    for (String user : blockedUsers) {
                        System.out.println(user);
                    }
                }
            } else if (choice.equals("7") && username.equals("admin")) {
                System.out.print("Enter username to unblock: ");
                String userToUnblock = input.nextLine();
                if (blockedUsers.remove(userToUnblock)) {
                    failedAttempts.put(userToUnblock, 0);
                    System.out.println("✅ User " + userToUnblock + " has been unblocked.");
                } else {
                    System.out.println("❌ User not found in blocked list.");
                }
            } else {
                System.out.println("Invalid choice!");
            }
        }
    }
}
