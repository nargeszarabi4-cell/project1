import java.util.HashMap;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        HashMap <String,String> info = new HashMap<>();
        info.put("admin","123456789");
        Users myUser = new Users();
        while (true) {
            System.out.println("1.Login 2.Register 3.Exit");
            System.out.print("Enter your choice: ");
            String choice = input.nextLine();
            if (choice.equals("1")) {
                System.out.print("Enter your username: ");
                String username = input.nextLine();
                System.out.print("Enter your password: ");
                String password = input.nextLine();
                boolean result = myUser.Login(username, password, info);
                if (result) {
                    System.out.println("Login Successful");
                    myUser.userMenu(username, password, info);
                } else  {
                    System.out.println("Login Failed");
                }
            } else if (choice.equals("2")) {
                System.out.print("Enter your username: ");
                String username = input.nextLine();
                System.out.print("Enter your password: ");
                String password = input.nextLine();
                System.out.print("Confirm your password: ");
                String confirmPassword = input.nextLine();
                myUser.Register(username, password, confirmPassword, info);

            } else if (choice.equals("3")) {
                break;
            } else {
                System.out.println("Wrong choice!!!");
            }
        }
    }
}
