# User Management System (Java)

A simple user management system written in **Java** with the following features:

## ✨ Features
- **Registration** with validation:
  - Prevents duplicate usernames
  - Checks password and confirmation match
  - Ensures password length is at least 8 characters
- **Login** with security limit:
  - If a user enters the wrong password 3 times in a row, their account is blocked
  - Successful logins are recorded with date and time in `Users.log`
- **User Menu**:
  - Change password
  - Logout
  - (Non-admin users only) Delete account
- **Admin Menu**:
  - View all accounts
  - View login log (`Users.log`)
  - View blocked users
  - Unblock users

## 📂 File Structure
- **Main.java** → Entry point of the program, handles the main menu (Login/Register/Exit)
- **Users.java** → Class containing user and admin operations
- **Users.log** → Text file storing usernames and timestamps of successful logins

## 🛠 Requirements
- **Java JDK 8** or higher
- A Java runtime environment (IDE such as IntelliJ IDEA, Eclipse, or terminal)

## 🚀 How to Run
1. Download or clone the source code.
2. Open the project in your IDE or terminal.
3. Compile and run:
   ```bash
   javac Main.java Users.java
   java Main
4. From the main menu, choose:

- 1 → Login

- 2 → Register

- 3 → Exit

## 📌 Security Notes
- Passwords are stored in plain text in this version (for simplicity).
  In real-world applications, use hashing algorithms such as SHA-256.
- The Users.log file records successful logins and can be viewed by the admin.


## 🖼 Example Run
```bash
1.Login 2.Register 3.Exit
Enter your choice: 1
Enter your username: admin
Enter your password: 123456789
Login Successful
2.Change Password 3.Logout
4.View All Accounts 5.View Login Log 6.View Blocked Users 7.Unblock User
Enter your choice: 5
=== Login Log ===
admin - 2025-09-23 14:40:12
```

## 📜 License
- This project is for educational purposes and can be used or modified without restrictions.
